export function compute(num) {
    if (num < 0) {
        return 0;
    }
    return num + 1;
}
