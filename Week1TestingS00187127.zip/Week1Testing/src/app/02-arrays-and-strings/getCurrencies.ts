export function getCurrencies() {
    return ['USD', 'EUR', 'GBP'];
}
